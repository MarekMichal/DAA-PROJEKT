/*1.1 Select nam vyberie vsetky udaje z tabulky zakaznikov a zoradi ich podla mena*/
SELECT * FROM zakaznici ORDER BY Meno;
/*1.2 Select nam vyberie vsetky udaje z tabulky produktov ktore maju cenu nizsiu ako 1000*/
SELECT * FROM produkty WHERE Cena < 1000;
/*1.3 Select nam vyberie vsetky udaje z tabulky zakaznikov ktore zacinaju menom Martin*/
SELECT * FROM zakaznici WHERE Meno LIKE 'Martin%';
/*1.4 Select nam vyberie Nazov cenu a pocet z tabulky produkty ktore maju mensiu cenu ako 500 a zoradi ich podla ceny*/
SELECT Nazov, Cena, Pocet FROM produkty WHERE Cena < 500 ORDER BY Cena;
/*2.1 Select nam vyberie vsetky udaje z tabulky zakaznici kde meno zacina Marek a mail zacina pismenom m alebo heslo zacina pismenom a*/
SELECT * FROM zakaznici WHERE Meno LIKE 'Marek%' AND mail LIKE 'm%' OR heslo LIKE 'a%';
/*2.2 Select nam vyberie vsetky udaje z tabulky produkty kde nie je pocet produktov vacsi ako 10*/
SELECT * FROM produkty WHERE Pocet != 10;
/*2.3 Select nam vyberie vsetky udaje z tabulky produktov ktore maju i v nazve*/
SELECT * FROM produkty WHERE Nazov LIKE '%i%';
/*3.1 Select nam vyberie udaje z Poctu a kolko krat sa nachadza na sklade po rovnaky pocet produktov */
SELECT Pocet, COUNT(*) AS pocet FROM produkty GROUP BY Pocet;
/*3.2 Select nam vyberie udaje z Ceny a kolko produktov ma rovnaku cenu*/
SELECT Cena, COUNT(*) AS pocet FROM produkty GROUP BY Cena;
/*3.3 Select nam vyberie udaje z poctu_produktov a kolko kosikov ma rovnaky pocet_produktov okrem tych ktore maju pocet mensi ako 3*/
SELECT pocet_produktov, COUNT(*) AS pocet FROM kosik GROUP BY pocet_produktov HAVING pocet > 3;