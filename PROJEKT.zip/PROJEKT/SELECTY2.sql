/*4.1 Select nam vyberie Meno Mail a heslo z tabulky zakaznici a spoji ju s tabulkou kosik kde je pocet produktov 2 a zoradi ich podla Ceny_nakupu*/
SELECT Meno, Mail, Heslo FROM zakaznici JOIN kosik ON id = id_kosik WHERE pocet_produktov = 2 GROUP BY Cena_nakupu;
/*4.2 Select nam vyberie Nazov Cenu a Pocet z tabulky produktov a spoji ju s tabulkou kosik kde je cena_nakupu mensia ako 1000 a zoradi ich podla Ceny_nakupu*/
SELECT Nazov, Cena, Pocet FROM produkty JOIN kosik ON id_produktu = id_kosik WHERE Cena_nakupu < 1000 GROUP BY Cena_nakupu;
/*5.1 Select nam vyberie Meno ebstranku a adresu z obchodu kde je dodavatel Adrian_Mrkvicka*/
SELECT Meno, webstranka, adresa FROM obchod WHERE id_online_obchodu = (SELECT mail FROM dodavatel WHERE Meno = 'Adrian_Mrkvicka');
/*5.2 Select nam vyberie vsetky udaje z produktov kde je cena nakupu z kosika mensia ako 500*/
SELECT * FROM produkty WHERE id_online_obchodu = (SELECT Pocet_produktov FROM kosik WHERE Cena_nakupu > 2250);